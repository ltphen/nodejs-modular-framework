var modules = require("./../../../generic/modules/modules");

module.exports = modules.getModule("shared");