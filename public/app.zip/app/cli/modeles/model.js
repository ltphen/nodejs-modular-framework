var {{ModelName}} = function (parent) {
	this.parent = parent;
	this.module = require('./../main/main');
	
}

/**
* @params params Type description
*/

{{ModelName}}.prototype.method = function() {

	// your code here
	
};

module.exports =  {{ModelName}};
