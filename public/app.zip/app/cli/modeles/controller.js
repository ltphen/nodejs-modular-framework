var {{ControllerName}} = function (parent) {
	this.parent = parent;
	this.module = require('./../main/main');
}

/**
* @params params Type description
*/

{{ControllerName}}.prototype.method = function (params) {

	// your code here
	
}

module.exports =  {{ControllerName}};