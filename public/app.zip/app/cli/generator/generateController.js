var g = require('./ClassGenerator');

g.generate("controller");