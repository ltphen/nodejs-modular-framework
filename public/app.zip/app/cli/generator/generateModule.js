var g = require('./ModuleGenerator');

g.generate();