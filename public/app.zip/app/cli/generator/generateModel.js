var g = require('./ClassGenerator');

g.generate("model");