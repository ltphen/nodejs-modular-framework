var g = require('./ClassGenerator');

g.generate("middleware");